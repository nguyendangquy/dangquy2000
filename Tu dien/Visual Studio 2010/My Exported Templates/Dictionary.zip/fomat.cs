﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using $safeprojectname$.db;

namespace $safeprojectname$
{
    public partial class fomat : Form
    {
        private dao db;
        public fomat()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void fomat_Load(object sender, EventArgs e)
        {
            db = new dao();
            DataTable tbl = db.getListWord();   
        }
    }
}
