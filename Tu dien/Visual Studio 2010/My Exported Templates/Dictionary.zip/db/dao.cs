using System;
using System.Collections.Generic;
using System.Text;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;
namespace $safeprojectname$.db
{
    class dao
    {
        static string path=Application.StartupPath;
        private SqlDataAdapter apdapter;
        private SqlConnection conn;
        private SqlCommand cmd;
        private static string strConn = @"Data Source=.\SQLEXPRESS;AttachDbFilename="+path+"\\db\\tudien.mdf;Integrated Security=True;User Instance=True";
        public dao()
        {
            openConn();
        }

        private void openConn()
        {
            conn = new SqlConnection(strConn);
            conn.Open();
            cmd = new SqlCommand();
            cmd.Connection = conn;
            apdapter = new SqlDataAdapter(cmd);
        }

        public void closeConn()
        {
            conn.Close();
            apdapter = null;
            cmd = null;
            conn = null;
        }

        public DataTable getListWord()
        {
            DataTable tbl = null;
            try
            {
                 string strSelect = "SELECT id, tentu_tienganh, loai_tu,  giaithich_tiengviet  FROM table_tu order by tentu_tienganh ASC";
                //cmd.CommandType = CommandType.Text;
                cmd.CommandText = strSelect;
                cmd.ExecuteNonQuery();
                DataSet ds = new DataSet();
                apdapter.SelectCommand = cmd;
                apdapter.Fill(ds);
                tbl= ds.Tables[0];
            }
            catch (SqlException e)
            {
                MessageBox.Show(e.ToString());
            }
            return tbl;
        }

        public DataTable getListWordEnglish(string keyword)
        {
            DataTable tbl = null;
            keyword = keyword.Trim();
            try
            {
                string strSelect = "select tentu_tienganh from table_tu where tentu_tienganh like '" + keyword + "%'";
                cmd.CommandText = strSelect;
                cmd.ExecuteNonQuery();
                DataSet ds = new DataSet();
                apdapter.SelectCommand = cmd;
                apdapter.Fill(ds);
                tbl = ds.Tables[0];
            }
            catch (SqlException e)
            {
                MessageBox.Show(e.ToString());
            }
            return tbl;
        }
        
        public DataTable getContentEnglishByWord(string word)
        {
            DataTable tbl = null;
            try
            {
                string strSelect = "select * from table_tu where tentu_tienganh='" + word + "'";
                cmd.CommandText = strSelect;
                cmd.ExecuteNonQuery();
                DataSet ds = new DataSet();
                apdapter.SelectCommand = cmd;
                apdapter.Fill(ds);
                tbl = ds.Tables[0];
            }
            catch (SqlException e)
            {
                MessageBox.Show(e.ToString());
            }
            return tbl;
        }
        
    }
}
